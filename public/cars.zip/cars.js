var cars = [{
    id: '1smrt',
    name: 'Smart Fortwo',
    img: 'pics/Smart_Fortwo_2012_01_1024x768.jpg',
    pricePerDay: 25,
    pricePerKm: 0.12
}, {
    id: '2adsp',
    name: 'Audi A1 Sportback',
    img: 'pics/Audi_A1_2012_06_1024x768.jpg',
    pricePerDay: 49,
    pricePerKm: 0.25
}, {
    id: '3shcb',
    name: 'Shelby AC Cobra',
    img: 'pics/Shelby_AC-C_160_1024x768.jpg',
    pricePerDay: 440,
    pricePerKm: 2.25
}, {
    id: '4bmi',
    name: 'BMW i3',
    img: 'pics/BMW_2014_i3_010_1024x768.jpg',
    pricePerDay: 54,
    pricePerKm: 0.50
}, {
    id: '5pgot2008',
    name: 'Peugeot 2008',
    img: 'pics/Peugeot_2008_2014_07_1024x768.jpg',
    pricePerDay: 38,
    pricePerKm: 0.25
}, {
    id: '6vwgol',
    name: 'Volkswagen Golf VII',
    img: 'pics/Volkswagen_Golf_2013__06_1024x768.jpg',
    pricePerDay: 42,
    pricePerKm: 0.30
}, {
    id: '7abt500',
    name: 'Abarth 500C',
    img: 'pics/Fiat_2013_abarth_500C_001_1024x768.jpg',
    pricePerDay: 89,
    pricePerKm: 0.60
}, {
    id: '8jpltd',
    name: 'Jeep Wrangler',
    img: 'pics/Jeep_Wrangler_Moab_2013_01_1024x768.jpg',
    pricePerDay: 195,
    pricePerKm: 0.80
}, {
    id: '9rntmeg',
    name: 'Renault Mégane RS',
    img: 'pics/Renault_Megane_RS_2014_01_1024x768.jpg',
    pricePerDay: 140,
    pricePerKm: 0.70
}, {
    id: '10ft124',
    name: 'Fiat 124 Spider',
    img: 'pics/Fiat_124Spider_02.jpg',
    pricePerDay: 155,
    pricePerKm: 0.65
}, {
    id: '11skdoct',
    name: 'Skoda Octavia',
    img: 'pics/Skoda_Octavia_2013_14_1024x768.jpg',
    pricePerDay: 72,
    pricePerKm: 0.40
}, {
    id: '12pgot106',
    name: 'Peugeot 106',
    img: 'pics/Peugeot_106.jpg',
    pricePerDay: 19,
    pricePerKm: 0.15
}];